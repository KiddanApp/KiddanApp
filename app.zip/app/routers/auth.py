from fastapi import APIRouter, HTTPException, Depends, Response
from sqlalchemy.ext.asyncio import AsyncSession
from starlette.requests import Request
from motor.motor_asyncio import AsyncIOMotorDatabase
from app.schemas import UserSignup, UserLogin, UserOut
from app.database import get_db
from app.db import get_database
from app.services.user_service import UserService
from app.services.progress_service import ProgressService

router = APIRouter()

def get_user_service(session: AsyncSession = Depends(get_db)) -> UserService:
    return UserService(session)

def get_progress_service(db: AsyncIOMotorDatabase = Depends(get_database)) -> ProgressService:
    return ProgressService(db)

@router.post("/signup", response_model=UserOut)
async def signup(
    user_data: UserSignup,
    response: Response,
    service: UserService = Depends(get_user_service)
):
    # Check if email is already registered
    existing_user = await service.get_user_by_email(user_data.email)
    if existing_user:
        raise HTTPException(
            status_code=409,
            detail="An account with this email already exists"
        )

    try:
        user = await service.create_user(user_data.email, user_data.password)

        response.set_cookie(
            key="user_id",
            value=user.id,
            httponly=True,
            secure=False,  
            samesite="lax"
        )
        return UserOut(
            id=user.id,
            email=user.email,
            created_at=user.created_at.isoformat(),
            lessons_completed=[]
        )
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))

@router.post("/login", response_model=UserOut)
async def login(
    user_data: UserLogin,
    response: Response,
    service: UserService = Depends(get_user_service),
    progress_service: ProgressService = Depends(get_progress_service)
):
    user = await service.authenticate_user(user_data.email, user_data.password)
    if not user:
        raise HTTPException(status_code=401, detail="Invalid email or password")

    # Set session
    response.set_cookie(
        key="user_id",
        value=user.id,
        httponly=True,
        secure=False,
        samesite="lax"
    )

    # Get completed lessons
    progress_list = await progress_service.get_all_user_progress(user.id)
    lessons_completed = [p.character_id for p in progress_list if p.completed]

    return UserOut(
        id=user.id,
        email=user.email,
        created_at=user.created_at.isoformat(),
        lessons_completed=lessons_completed
    )

@router.post("/logout")
async def logout(response: Response):
    response.delete_cookie(key="user_id")
    return {"message": "Logged out successfully"}

@router.get("/me/{user_id}", response_model=UserOut)
async def get_current_user(
    user_id: str,
    request: Request,
    service: UserService = Depends(get_user_service),
    progress_service: ProgressService = Depends(get_progress_service)
):

    if not user_id:
        raise HTTPException(status_code=401, detail="Not authenticated")

    user = await service.get_user_by_id(user_id)
    if not user:
        raise HTTPException(status_code=401, detail="User not found")

    # Get completed lessons
    progress_list = await progress_service.get_all_user_progress(user_id)
    lessons_completed = [p.character_id for p in progress_list if p.completed]

    return UserOut(
        id=user.id,
        email=user.email,
        created_at=user.created_at.isoformat(),
        lessons_completed=lessons_completed
    )
